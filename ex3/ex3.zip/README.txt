NLP - 67658
Exercise 3
Omer Mushlion 208271197
Itay Chachy 208489732
Itay Kahana 316385962

The zip file contains the following:
1. ex3.py
2. Ex3 NLP.pdf - contains the plots of the results, and the answers to question 1-3.
3. README.txt
