NLP - 67658
Exercise 2
Omer Mushlion 208271197
Itay Chachy 208489732
Itay Kahana 316385962

The zip file contains the following:
1. Ex2 NLP.pdf
2. ex2.py
